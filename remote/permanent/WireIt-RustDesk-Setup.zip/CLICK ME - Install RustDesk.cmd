@echo off
title WireIt RustDesk setup
setlocal
set "WIREIT_PS1=%~dp0files\Install-WireIt-RustDesk.ps1"
if not exist "%WIREIT_PS1%" (
  echo.
  echo  Install-WireIt-RustDesk.ps1 is missing.
  echo  Right-click the zip, choose "Extract All", then run this file from the extracted folder.
  echo.
  pause
  exit /b 1
)

rem Already running as admin? Run the script right here.
net session >nul 2>&1
if %errorlevel%==0 (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%WIREIT_PS1%"
  exit /b
)

rem Not admin yet: ask Windows (UAC). Pass this user's Desktop so the ID/password file lands where you can see it.
echo.
echo  Windows will ask for admin rights. Click Yes.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); try { Start-Process -FilePath powershell.exe -Verb RunAs -ErrorAction Stop -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('\"'+$env:WIREIT_PS1+'\"'),'-DesktopPath',('\"'+$d+'\"')) } catch { exit 1 }"
if errorlevel 1 (
  echo  Admin rights were not given, so nothing was installed. Run it again and click Yes.
  echo.
  pause
  exit /b 1
)
exit /b 0
