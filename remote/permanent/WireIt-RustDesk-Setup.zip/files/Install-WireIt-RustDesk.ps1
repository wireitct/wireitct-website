<#
  Install-WireIt-RustDesk.ps1  -  WireIt CT one-click RustDesk setup for a new Windows PC.
  Run it through "CLICK ME - Install RustDesk" (that asks Windows for admin rights).
  Windows PowerShell 5.1. Fixed code, no AI, no Tab needed.

  What it does:
    1. Installs RustDesk 1.5.1 (bundled installer, or the official GitHub download), SHA-256 checked.
    2. RustDesk runs as a Windows service that starts with Windows.
    3. Points it at the WireIt server 32.221.145.52 with the WireIt key.
    4. Makes a new random 20-character permanent password (nothing is hardcoded).
    5. Power: never sleep, never hibernate, network card stays awake.
    6. Shows the RustDesk ID + password and saves both to a text file on the Desktop.
  The password is never written to the log.
#>
param(
  [string]$DesktopPath = ''
)

$ErrorActionPreference = 'Continue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

# ---------------------------------------------------------------- fixed settings
$RdVersion   = '1.5.1'
$RdFile      = 'rustdesk-1.5.1-x86_64.exe'
$RdUrl       = 'https://github.com/rustdesk/rustdesk/releases/download/1.5.1/rustdesk-1.5.1-x86_64.exe'
$RdSha256    = '319206042390ebfcba934cf0baa2f612f34de463c78c843b7cb8c22097c4bf7b'
$Server      = '32.221.145.52'
$Key         = 'PHR3q7ZMF7Qxq2OKKNsy6EzXFeVeqFP8b3ha4gqTkps='
$Exe         = Join-Path $env:ProgramFiles 'RustDesk\rustdesk.exe'
$CfgDir      = Join-Path $env:WINDIR 'ServiceProfiles\LocalService\AppData\Roaming\RustDesk\config'
$Toml2       = Join-Path $CfgDir 'RustDesk2.toml'
$Toml1       = Join-Path $CfgDir 'RustDesk.toml'
$Here        = $PSScriptRoot
$LogDir      = 'C:\WireIt\Logs'
$script:Results = New-Object System.Collections.ArrayList

# ---------------------------------------------------------------- helpers
New-Item -ItemType Directory -Force -Path $LogDir -ErrorAction SilentlyContinue | Out-Null
$Log = Join-Path $LogDir ('rustdesk-oneclick-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')

function Write-Log([string]$Text) {
  try { Add-Content -Path $Log -Value ((Get-Date -Format 'HH:mm:ss') + '  ' + $Text) -ErrorAction SilentlyContinue } catch { }
}
function Say([string]$Text, [string]$Color = 'Gray') { Write-Host $Text -ForegroundColor $Color; Write-Log $Text }
function Step([string]$Text) { Write-Host ''; Say ('== ' + $Text) 'Cyan' }
function Add-Result([string]$Name, [string]$Status, [string]$Detail) { [void]$script:Results.Add([pscustomobject]@{ Name = $Name; Status = $Status; Detail = $Detail }); Write-Log ('RESULT ' + $Name + ': ' + $Status + ' ' + $Detail) }

function Test-IsAdmin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-Sha256([string]$Path) {
  return (Get-FileHash -Path $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function New-StrongPassword([int]$Length = 20) {
  # letters + digits only (no quotes or spaces, so it passes safely on the RustDesk command line);
  # no look-alikes (0 O o 1 l I). 56 symbols x 20 chars = about 116 bits.
  $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'.ToCharArray()
  $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  try {
    while ($true) {
      $chars = New-Object char[] $Length
      $buf = New-Object byte[] 1
      for ($i = 0; $i -lt $Length; $i++) {
        # rejection sampling: no bias
        do { $rng.GetBytes($buf) } while ($buf[0] -ge (256 - (256 % $alphabet.Length)))
        $chars[$i] = $alphabet[$buf[0] % $alphabet.Length]
      }
      $p = -join $chars
      if ($p -cmatch '[A-Z]' -and $p -cmatch '[a-z]' -and $p -match '[0-9]') { return $p }
    }
  } finally { $rng.Dispose() }
}

function Invoke-Rd([string[]]$CliArgs, [int]$TimeoutSec = 20) {
  # rustdesk.exe is a window program: always run it with a time limit and capture what it prints
  $out = Join-Path $env:TEMP ('rd-' + [guid]::NewGuid().ToString('N') + '.txt')
  $argLine = ($CliArgs | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } }) -join ' '
  $text = ''
  try {
    $p = Start-Process -FilePath $Exe -ArgumentList $argLine -RedirectStandardOutput $out -PassThru -WindowStyle Hidden -ErrorAction Stop
    if (-not $p.WaitForExit($TimeoutSec * 1000)) { try { $p.Kill() } catch { } }
  } catch { Write-Log ('rustdesk.exe call failed: ' + $_.Exception.Message) }
  Start-Sleep -Seconds 1
  if (Test-Path $out) { $text = [string](Get-Content $out -Raw -ErrorAction SilentlyContinue); Remove-Item $out -Force -ErrorAction SilentlyContinue }
  if ($null -eq $text) { $text = '' }
  return $text.Trim()
}

function Get-TomlOptions([string]$Path) {
  $h = @{}
  if (-not (Test-Path $Path)) { return $h }
  $inOpts = $false
  foreach ($l in @(Get-Content $Path -ErrorAction SilentlyContinue)) {
    if ($l -match '^\s*\[(.+)\]\s*$') { $inOpts = ($Matches[1].Trim() -eq 'options'); continue }
    if ($inOpts -and $l -match "^\s*([A-Za-z0-9_\-]+)\s*=\s*'(.*)'\s*$") { $h[$Matches[1]] = $Matches[2] }
  }
  return $h
}

function Set-TomlOptions([string]$Path, [hashtable]$Options) {
  # writes [options] keys straight into RustDesk2.toml (the fallback if the command line did not take)
  $lines = @()
  if (Test-Path $Path) { $lines = @(Get-Content $Path -ErrorAction SilentlyContinue) }
  $out = New-Object System.Collections.ArrayList
  $inOpts = $false; $sawOpts = $false
  foreach ($l in $lines) {
    if ($l -match '^\s*\[(.+)\]\s*$') {
      $inOpts = ($Matches[1].Trim() -eq 'options')
      [void]$out.Add($l)
      if ($inOpts) { $sawOpts = $true; foreach ($k in $Options.Keys) { [void]$out.Add(("{0} = '{1}'" -f $k, $Options[$k])) } }
      continue
    }
    if ($inOpts -and $l -match '^\s*([A-Za-z0-9_\-]+)\s*=' -and $Options.ContainsKey($Matches[1])) { continue }  # replaced above
    [void]$out.Add($l)
  }
  if (-not $sawOpts) { [void]$out.Add('[options]'); foreach ($k in $Options.Keys) { [void]$out.Add(("{0} = '{1}'" -f $k, $Options[$k])) } }
  New-Item -ItemType Directory -Force -Path (Split-Path $Path) -ErrorAction SilentlyContinue | Out-Null
  [IO.File]::WriteAllLines($Path, [string[]]$out, (New-Object Text.UTF8Encoding($false)))
}

function Test-Tcp([string]$HostName, [int]$Port, [int]$TimeoutMs = 4000) {
  $c = New-Object System.Net.Sockets.TcpClient
  try {
    $ar = $c.BeginConnect($HostName, $Port, $null, $null)
    if ($ar.AsyncWaitHandle.WaitOne($TimeoutMs) -and $c.Connected) { $c.EndConnect($ar); return $true }
    return $false
  } catch { return $false } finally { $c.Close() }
}

function Get-RdId {
  $id = Invoke-Rd @('--get-id')
  if ($id -match '(\d{6,12})') { return $Matches[1] }
  # the way rd4.ps1 reads it, with a time limit
  try {
    $j = Start-Job -ScriptBlock { param($e) (& $e --get-id | Out-String) } -ArgumentList $Exe
    if (Wait-Job $j -Timeout 20) { $id = [string](Receive-Job $j) }
    Remove-Job $j -Force -ErrorAction SilentlyContinue
    if ($id -match '(\d{6,12})') { return $Matches[1] }
  } catch { }
  if (Test-Path $Toml1) {
    $m = Select-String -Path $Toml1 -Pattern "^\s*id\s*=\s*'?(\d{6,12})'?" | Select-Object -First 1
    if ($m) { return $m.Matches[0].Groups[1].Value }
  }
  return $null
}

function Wait-Enter { Write-Host ''; [void](Read-Host 'Press Enter to close this window') }

# ---------------------------------------------------------------- start
Clear-Host
Say ('WireIt RustDesk setup   ' + (Get-Date -Format 'yyyy-MM-dd HH:mm') + '   PC: ' + $env:COMPUTERNAME) 'White'
Say ('Log: ' + $Log) 'DarkGray'

if (-not (Test-IsAdmin)) {
  Say 'This needs admin rights. Double-click "CLICK ME - Install RustDesk" and click Yes.' 'Red'
  Wait-Enter; exit 1
}

# ---------------------------------------------------------------- 1. installer
Step ('RustDesk ' + $RdVersion)
$svc = Get-Service -Name RustDesk -ErrorAction SilentlyContinue
if ($svc -and (Test-Path $Exe)) {
  $v = (Get-Item $Exe).VersionInfo.FileVersion
  Say ('RustDesk is already installed (version ' + $v + '). Keeping it and setting it up.') 'Yellow'
  Add-Result 'Install' 'SKIPPED' ('already installed, version ' + $v)
} else {
  $setup = $null
  $local = Join-Path $Here $RdFile
  if (Test-Path $local) {
    $h = Get-Sha256 $local
    if ($h -eq $RdSha256) { $setup = $local; Say 'Bundled installer: hash OK.' 'Green' }
    else { Say ('Bundled installer has the WRONG hash (' + $h + '). Ignoring it, downloading instead.') 'Yellow' }
  }
  if (-not $setup) {
    $dl = Join-Path $env:TEMP $RdFile
    Say ('Downloading from GitHub: ' + $RdUrl)
    $ok = $false
    for ($try = 1; $try -le 3 -and -not $ok; $try++) {
      try {
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $RdUrl -OutFile $dl -UseBasicParsing -TimeoutSec 300 -ErrorAction Stop
        $ok = $true
      } catch { Say ('Download try ' + $try + ' failed: ' + $_.Exception.Message) 'Yellow'; Start-Sleep -Seconds 5 }
    }
    if ($ok) {
      $h = Get-Sha256 $dl
      if ($h -eq $RdSha256) { $setup = $dl; Say 'Download: hash OK.' 'Green' }
      else { Remove-Item $dl -Force -ErrorAction SilentlyContinue; Say ('Download has the WRONG hash (' + $h + '). Deleted it. Stopping.') 'Red' }
    }
  }
  if (-not $setup) {
    Say 'No good RustDesk installer. Check the internet connection and run this again.' 'Red'
    Wait-Enter; exit 2
  }
  Unblock-File -Path $setup -ErrorAction SilentlyContinue
  Say 'Installing (about a minute)...'
  Start-Process -FilePath $setup -ArgumentList '--silent-install' | Out-Null
  for ($i = 0; $i -lt 90; $i++) {
    Start-Sleep -Seconds 2
    if ((Get-Service -Name RustDesk -ErrorAction SilentlyContinue) -and (Test-Path $Exe)) { break }
  }
  if (-not ((Get-Service -Name RustDesk -ErrorAction SilentlyContinue) -and (Test-Path $Exe))) {
    Say 'RustDesk did not install (no service after 3 minutes). Run this again; if it repeats, install RustDesk by hand.' 'Red'
    Wait-Enter; exit 3
  }
  Start-Sleep -Seconds 15
  Add-Result 'Install' 'OK' ('RustDesk ' + $RdVersion + ' installed')
}

# ---------------------------------------------------------------- 2. service starts with Windows
Step 'Service: start with Windows'
Set-Service -Name RustDesk -StartupType Automatic -ErrorAction SilentlyContinue
& sc.exe failure RustDesk reset= 86400 actions= restart/10000/restart/10000/restart/60000 | Out-Null
if ((Get-Service -Name RustDesk).Status -ne 'Running') { Start-Service -Name RustDesk -ErrorAction SilentlyContinue }
$svc = Get-Service -Name RustDesk -ErrorAction SilentlyContinue
$start = (Get-CimInstance Win32_Service -Filter "Name='RustDesk'" -ErrorAction SilentlyContinue).StartMode
Say ('Service: ' + $svc.Status + ', start: ' + $start)
if ($start -eq 'Auto') { Add-Result 'Service' 'OK' ('starts with Windows, now ' + $svc.Status) } else { Add-Result 'Service' 'CHECK' ('start mode is ' + $start) }

# ---------------------------------------------------------------- 3. WireIt server + unattended access
Step ('Server: ' + $Server)
$opts = [ordered]@{
  'custom-rendezvous-server' = $Server
  'relay-server'             = $Server
  'key'                      = $Key
  'approve-mode'             = 'password'
  'verification-method'      = 'use-permanent-password'
}
# the RustDesk window in the user session can overwrite the settings: close it first (the service keeps running)
Get-Process rustdesk -ErrorAction SilentlyContinue | Where-Object { $_.SessionId -ne 0 } | Stop-Process -Force -ErrorAction SilentlyContinue
$good = $false
for ($n = 1; $n -le 3 -and -not $good; $n++) {
  foreach ($k in $opts.Keys) { [void](Invoke-Rd @('--option', $k, $opts[$k])) }
  Start-Sleep -Seconds 3
  $now = Get-TomlOptions $Toml2
  $good = ($now['custom-rendezvous-server'] -eq $Server -and $now['relay-server'] -eq $Server -and $now['key'] -eq $Key)
  if (-not $good) { Say ('Settings not saved yet, try ' + $n) 'Yellow'; Restart-Service -Name RustDesk -Force -ErrorAction SilentlyContinue; Start-Sleep -Seconds 8 }
}
if (-not $good) {
  Say 'Writing the settings file directly.' 'Yellow'
  Stop-Service -Name RustDesk -Force -ErrorAction SilentlyContinue
  Get-Process rustdesk -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
  $h = @{}; foreach ($k in $opts.Keys) { $h[$k] = $opts[$k] }
  Set-TomlOptions $Toml2 $h
  Start-Service -Name RustDesk -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 8
  $now = Get-TomlOptions $Toml2
  $good = ($now['custom-rendezvous-server'] -eq $Server -and $now['relay-server'] -eq $Server -and $now['key'] -eq $Key)
}
if ($good) { Say 'Server and key set.' 'Green'; Add-Result 'Server' 'OK' ($Server + ' + WireIt key') }
else { Say 'Could not confirm the server settings.' 'Red'; Add-Result 'Server' 'FAILED' 'set it by hand: Settings > Network > ID/Relay server' }

# ---------------------------------------------------------------- 4. permanent password
Step 'Permanent password'
$pw = New-StrongPassword 20
$before = ''
if (Test-Path $Toml1) { $before = [string](Get-Content $Toml1 -Raw -ErrorAction SilentlyContinue) }
[void](Invoke-Rd @('--password', $pw))
Restart-Service -Name RustDesk -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 12
$after = ''
if (Test-Path $Toml1) { $after = [string](Get-Content $Toml1 -Raw -ErrorAction SilentlyContinue) }
$pwLine = $after -match "(?m)^\s*password\s*=\s*'.+'"
if ($pwLine -and $after -ne $before) { Add-Result 'Password' 'OK' 'new random 20-character password set' ; Say 'Password set.' 'Green' }
elseif ($pwLine) { Add-Result 'Password' 'CHECK' 'a password is stored, but the file did not change - test a connection'; Say 'Password stored, but could not confirm it changed. Test a connection.' 'Yellow' }
else { Add-Result 'Password' 'FAILED' 'not stored - set it by hand in RustDesk > Settings > Security'; Say 'Could not confirm the password.' 'Red' }

# ---------------------------------------------------------------- 5. power: never sleep
Step 'Power: never sleep'
$hp = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'   # High performance
& powercfg.exe /setactive $hp 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
  $dup = (& powercfg.exe -duplicatescheme $hp 2>&1 | Out-String)
  if ($dup -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { & powercfg.exe /setactive $Matches[1] 2>&1 | Out-Null }
}
& powercfg.exe /change standby-timeout-ac 0   | Out-Null
& powercfg.exe /change standby-timeout-dc 0   | Out-Null
& powercfg.exe /change hibernate-timeout-ac 0 | Out-Null
& powercfg.exe /change hibernate-timeout-dc 0 | Out-Null
& powercfg.exe /change monitor-timeout-ac 15  | Out-Null
& powercfg.exe /hibernate off 2>&1 | Out-Null
try { Get-NetAdapter -Physical -ErrorAction Stop | ForEach-Object { Disable-NetAdapterPowerManagement -Name $_.Name -NoRestart -ErrorAction SilentlyContinue } } catch { }
$scheme = (& powercfg.exe /getactivescheme 2>&1 | Out-String).Trim()
Say $scheme
Add-Result 'Power' 'OK' 'never sleep, never hibernate, screen off after 15 min, network card stays awake'

# ---------------------------------------------------------------- 6. ID + server check
Step 'RustDesk ID'
$id = $null
for ($i = 0; $i -lt 6 -and -not $id; $i++) { $id = Get-RdId; if (-not $id) { Start-Sleep -Seconds 5 } }
if ($id) { Add-Result 'ID' 'OK' $id } else { Add-Result 'ID' 'CHECK' 'could not read it - open RustDesk to see it' }
$reach = (Test-Tcp $Server 21116) -and (Test-Tcp $Server 21117)
if ($reach) { Add-Result 'Server reachable' 'OK' ($Server + ' ports 21116/21117 answer') }
else { Add-Result 'Server reachable' 'CHECK' ('cannot reach ' + $Server + ' 21116/21117 - check internet / firewall') }

# ---------------------------------------------------------------- 7. save to Desktop
if (-not $DesktopPath -or -not (Test-Path $DesktopPath)) { $DesktopPath = [Environment]::GetFolderPath('Desktop') }
$idText = $id; if (-not $idText) { $idText = '(not read - open RustDesk to see it)' }
$file = Join-Path $DesktopPath ('WireIt RustDesk - ' + $env:COMPUTERNAME + '.txt')
$body = @(
  'WireIt RustDesk - ' + $env:COMPUTERNAME,
  'Set up: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm'),
  '',
  'RustDesk ID: ' + $idText,
  'Password:    ' + $pw,
  '',
  'Server: ' + $Server + '   Key: ' + $Key,
  '',
  'Save the ID and password in Bitwarden (or text them to Tab), then DELETE this file.'
)
$saved = $false
try { [IO.File]::WriteAllLines($file, [string[]]$body, (New-Object Text.UTF8Encoding($false))); $saved = $true } catch { Write-Log ('Desktop file failed: ' + $_.Exception.Message) }
if ($saved) { Add-Result 'Desktop file' 'OK' $file; Write-Log 'Desktop file written (password not logged).' } else { Add-Result 'Desktop file' 'FAILED' 'write the ID and password down from this screen' }

# ---------------------------------------------------------------- summary
Write-Host ''
Write-Host '==================== SUMMARY ====================' -ForegroundColor White
foreach ($r in $script:Results) {
  $c = 'Green'; if ($r.Status -eq 'CHECK' -or $r.Status -eq 'SKIPPED') { $c = 'Yellow' }; if ($r.Status -eq 'FAILED') { $c = 'Red' }
  Write-Host ('{0,-17} {1,-8} {2}' -f $r.Name, $r.Status, $r.Detail) -ForegroundColor $c
}
Write-Host ''
Write-Host '   RustDesk ID:  ' -NoNewline; Write-Host (' ' + $idText + ' ') -ForegroundColor Black -BackgroundColor Green
Write-Host '   Password:     ' -NoNewline; Write-Host (' ' + $pw + ' ') -ForegroundColor Black -BackgroundColor Yellow
Write-Host ''
if ($saved) { Write-Host ('   Also saved on the Desktop: ' + (Split-Path $file -Leaf)) -ForegroundColor White }
Write-Host '   Save both in Bitwarden or text them to Tab, then delete the Desktop file.' -ForegroundColor White
Write-Log 'Done.'
$pw = $null
Wait-Enter
