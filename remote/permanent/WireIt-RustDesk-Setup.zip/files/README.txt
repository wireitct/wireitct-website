Install WireIt RustDesk (new Windows PC, about 3 minutes, internet needed for the server check)
1. Right-click rustdesk-oneclick.zip > Extract All. Open the folder, double-click "CLICK ME - Install RustDesk", click Yes (if "Windows protected your PC" shows, click More info > Run anyway).
2. It installs RustDesk 1.5.1 (bundled, hash-checked; downloads from GitHub if missing) as a service that starts with Windows, on our server 32.221.145.52 with our key.
3. It makes a new random password, sets the PC to never sleep, and shows the RustDesk ID + password in a summary at the end.
4. The same ID + password are saved on the Desktop as "WireIt RustDesk - <PC name>.txt": text them to Tab or save them in Bitwarden, then delete that file. Log: C:\WireIt\Logs.
